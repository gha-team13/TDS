import { Beaker, Wrench, Gem, Rocket, Globe2 } from 'lucide-react';
import { StageData } from './types';

export const stages: StageData[] = [
  {
    id: 'experiment',
    title: 'Experiment',
    shortDesc: 'Test a hypothesis quickly.',
    colorClass: 'bg-blue-500',
    bgLightClass: 'bg-blue-50',
    borderClass: 'border-blue-200',
    textClass: 'text-blue-700',
    icon: Beaker,
    definition: 'A rapid, low-cost test designed to validate or invalidate a specific hypothesis or assumption about a problem or potential solution.',
    primaryGoal: 'Learning and discovery. Failure is an acceptable and expected outcome if it provides valuable insights.',
    duration: 'Days to a few weeks.',
    prerequisites: [
      'A clear, testable hypothesis.',
      'A defined metric for success/failure.',
      'Minimal resources (time/budget).'
    ],
    keyQuestions: [
      'Is this idea even possible?',
      'Do users actually have this problem?',
      'What is the quickest way to test our riskiest assumption?'
    ],
    successCriteria: [
      'Clear validation or invalidation of the hypothesis.',
      'Actionable learnings documented.',
      'Decision made on whether to proceed further.'
    ],
    deliverables: [
      'Experiment design document.',
      'Data collected (qualitative or quantitative).',
      'Findings report (Go/No-Go decision).'
    ],
    example: 'Creating a simple landing page with a "Sign Up" button for a non-existent product to see if people click it (testing demand).'
  },
  {
    id: 'poc',
    title: 'Proof of Concept (PoC)',
    shortDesc: 'Prove technical feasibility.',
    colorClass: 'bg-violet-500',
    bgLightClass: 'bg-violet-50',
    borderClass: 'border-violet-200',
    textClass: 'text-violet-700',
    icon: Wrench,
    definition: 'A small exercise to test a discrete design idea or assumption to demonstrate that a specific technology or integration is technically feasible.',
    primaryGoal: 'Technical validation. Proving that "it can be built" in your specific environment.',
    duration: '2 to 6 weeks.',
    prerequisites: [
      'A validated problem (often from an experiment).',
      'Specific technical uncertainties identified.',
      'Access to necessary technical environments/tools.'
    ],
    keyQuestions: [
      'Can this technology integrate with our legacy systems?',
      'Does the proposed architecture actually work?',
      'Can we achieve the required performance at a small scale?'
    ],
    successCriteria: [
      'Technical hurdles overcome or identified as blockers.',
      'Working prototype (often ugly, not production-ready).',
      'Clear understanding of technical requirements for the next phase.'
    ],
    deliverables: [
      'Working code/prototype (throwaway or foundational).',
      'Technical architecture diagram.',
      'Feasibility report.'
    ],
    example: 'Building a small script to ensure a new AI API can successfully authenticate and return data when queried from your internal servers.'
  },
  {
    id: 'pov',
    title: 'Proof of Value (PoV)',
    shortDesc: 'Prove business ROI.',
    colorClass: 'bg-pink-500',
    bgLightClass: 'bg-pink-50',
    borderClass: 'border-pink-200',
    textClass: 'text-pink-700',
    icon: Gem,
    definition: 'An initiative to demonstrate that a proposed solution will deliver the expected business benefits and return on investment (ROI) before committing to a full build.',
    primaryGoal: 'Business validation. Proving that "it is worth building" and solves the problem effectively.',
    duration: '4 to 12 weeks.',
    prerequisites: [
      'Technical feasibility proven (PoC completed).',
      'Clear business metrics (KPIs) defined.',
      'Stakeholder buy-in for the evaluation.'
    ],
    keyQuestions: [
      'Does this solution actually save time/money or generate revenue?',
      'Is the user experience acceptable to the target audience?',
      'What is the projected ROI if we scale this?'
    ],
    successCriteria: [
      'Measurable improvement in target KPIs.',
      'Positive feedback from a small group of test users.',
      'Approved business case for a pilot.'
    ],
    deliverables: [
      'Business case document.',
      'ROI analysis.',
      'User feedback report.'
    ],
    example: 'Using a new automated tool to process 100 historical invoices to prove it reduces processing time by 50% compared to the manual method.'
  },
  {
    id: 'pilot',
    title: 'Pilot',
    shortDesc: 'Limited production rollout.',
    colorClass: 'bg-amber-500',
    bgLightClass: 'bg-amber-50',
    borderClass: 'border-amber-200',
    textClass: 'text-amber-700',
    icon: Rocket,
    definition: 'An initial roll-out of a system into production, targeting a limited scope (e.g., one department, one geographic region, or a subset of users) to test it in the real world.',
    primaryGoal: 'Operational validation. Testing the solution, deployment process, and support structures in a live environment.',
    duration: '3 to 6 months.',
    prerequisites: [
      'Business value proven (PoV completed).',
      'Production-ready (or near-ready) solution.',
      'Support and training materials prepared.',
      'Identified pilot group.'
    ],
    keyQuestions: [
      'How does the system perform under real-world daily use?',
      'Are our training and support processes effective?',
      'What unforeseen operational issues arise?'
    ],
    successCriteria: [
      'Stable operation in the production environment.',
      'High adoption rate among the pilot group.',
      'Support tickets manageable and resolvable.',
      'Final sign-off for enterprise-wide scale.'
    ],
    deliverables: [
      'Live system (limited scope).',
      'Operational runbooks.',
      'Pilot evaluation report and scale plan.'
    ],
    example: 'Deploying a new CRM system only to the European sales team for 3 months before rolling it out globally.'
  },
  {
    id: 'scale',
    title: 'Scale',
    shortDesc: 'Full enterprise deployment.',
    colorClass: 'bg-emerald-500',
    bgLightClass: 'bg-emerald-50',
    borderClass: 'border-emerald-200',
    textClass: 'text-emerald-700',
    icon: Globe2,
    definition: 'The process of deploying the validated solution across the entire organization or to the full target market, transitioning it from a project to a standard operational product.',
    primaryGoal: 'Maximizing impact. Ensuring widespread adoption, long-term stability, and realization of full business value.',
    duration: '6+ months (Ongoing).',
    prerequisites: [
      'Successful pilot completed.',
      'Robust infrastructure and architecture in place.',
      'Dedicated long-term product/support team assigned.',
      'Budget for enterprise licensing/infrastructure.'
    ],
    keyQuestions: [
      'How do we maintain performance as user numbers 10x?',
      'How do we drive adoption across resistant departments?',
      'What is the long-term roadmap for this product?'
    ],
    successCriteria: [
      'System handles full load without degradation.',
      'Target adoption metrics met across the enterprise.',
      'Transitioned successfully to business-as-usual (BAU) support.'
    ],
    deliverables: [
      'Fully deployed system.',
      'Enterprise-wide training program.',
      'Long-term product roadmap and SLA.'
    ],
    example: 'Rolling out the new CRM system to all 5,000 employees globally, integrating it with all core HR and finance systems.'
  }
];
