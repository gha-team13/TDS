import React, { useState } from 'react';
import { stages } from './data';
import { StageId } from './types';
import { StageDetail } from './components/StageDetail';
import { ComparisonTable } from './components/ComparisonTable';
import { LayoutGrid, List } from 'lucide-react';

const App: React.FC = () => {
  const [activeStageId, setActiveStageId] = useState<StageId>('experiment');
  const [viewMode, setViewMode] = useState<'detail' | 'compare'>('detail');

  const activeStage = stages.find(s => s.id === activeStageId) || stages[0];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Innovation Lifecycle Guide</h1>
              <p className="text-slate-500 text-sm mt-1">Understand the path from idea to enterprise scale.</p>
            </div>
            
            {/* View Toggle */}
            <div className="flex bg-slate-100 p-1 rounded-lg self-start md:self-auto">
              <button
                onClick={() => setViewMode('detail')}
                className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  viewMode === 'detail' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <List size={16} />
                Detailed View
              </button>
              <button
                onClick={() => setViewMode('compare')}
                className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  viewMode === 'compare' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <LayoutGrid size={16} />
                Compare All
              </button>
            </div>
          </div>

          {/* Stepper Navigation (Only show in detail view) */}
          {viewMode === 'detail' && (
            <div className="mt-8 relative">
              {/* Connecting Line */}
              <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-200 -translate-y-1/2 hidden md:block z-0"></div>
              
              <div className="relative z-10 flex flex-col md:flex-row justify-between gap-4 md:gap-0">
                {stages.map((stage, index) => {
                  const isActive = stage.id === activeStageId;
                  const isPast = stages.findIndex(s => s.id === activeStageId) > index;
                  const Icon = stage.icon;

                  return (
                    <button
                      key={stage.id}
                      onClick={() => setActiveStageId(stage.id)}
                      className={`flex flex-row md:flex-col items-center gap-3 md:gap-2 group text-left md:text-center w-full md:w-auto p-2 md:p-0 rounded-lg md:rounded-none transition-colors ${
                        isActive ? 'bg-slate-50 md:bg-transparent' : 'hover:bg-slate-50 md:hover:bg-transparent'
                      }`}
                    >
                      <div className={`
                        w-12 h-12 rounded-full flex items-center justify-center border-4 transition-all duration-300
                        ${isActive ? `${stage.colorClass} border-white shadow-md text-white scale-110` : 
                          isPast ? `${stage.colorClass} border-white text-white` : 
                          'bg-white border-slate-200 text-slate-400 group-hover:border-slate-300'}
                      `}>
                        <Icon size={20} />
                      </div>
                      <div>
                        <div className={`font-semibold text-sm md:text-base transition-colors ${
                          isActive ? stage.textClass : 'text-slate-600 group-hover:text-slate-900'
                        }`}>
                          {stage.title}
                        </div>
                        <div className="text-xs text-slate-400 hidden md:block max-w-[120px] mx-auto leading-tight mt-1">
                          {stage.shortDesc}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        {viewMode === 'detail' ? (
          <StageDetail stage={activeStage} />
        ) : (
          <ComparisonTable />
        )}
      </main>
    </div>
  );
};

export default App;
