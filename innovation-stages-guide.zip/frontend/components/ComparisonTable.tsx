import React from 'react';
import { stages } from '../data';

export const ComparisonTable: React.FC = () => {
  return (
    <div className="animate-in fade-in duration-500 overflow-x-auto pb-8">
      <table className="w-full min-w-[1000px] border-collapse bg-white rounded-xl shadow-sm overflow-hidden">
        <thead>
          <tr className="bg-slate-50 border-b border-slate-200">
            <th className="p-4 text-left font-semibold text-slate-600 w-48">Feature</th>
            {stages.map(stage => (
              <th key={stage.id} className={`p-4 text-left font-bold ${stage.textClass} w-64 border-l border-slate-100`}>
                <div className="flex items-center gap-2">
                  <stage.icon size={18} />
                  {stage.title}
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          <TableRow label="Primary Focus" dataKey="primaryGoal" />
          <TableRow label="Duration" dataKey="duration" />
          <TableRow label="Key Question" dataKey="keyQuestions" isList />
          <TableRow label="Success Criteria" dataKey="successCriteria" isList />
          <TableRow label="Deliverables" dataKey="deliverables" isList />
        </tbody>
      </table>
    </div>
  );
};

const TableRow: React.FC<{ label: string; dataKey: keyof typeof stages[0]; isList?: boolean }> = ({ label, dataKey, isList }) => (
  <tr className="hover:bg-slate-50/50 transition-colors">
    <td className="p-4 font-medium text-slate-700 align-top bg-slate-50/30">{label}</td>
    {stages.map(stage => (
      <td key={stage.id} className="p-4 text-slate-600 align-top border-l border-slate-100 text-sm">
        {isList ? (
          <ul className="list-disc list-inside space-y-1">
            {(stage[dataKey] as string[]).map((item, i) => (
              <li key={i} className="leading-snug">{item}</li>
            ))}
          </ul>
        ) : (
          <p className="leading-snug">{stage[dataKey] as string}</p>
        )}
      </td>
    ))}
  </tr>
);
