import React from 'react';
import { StageData } from '../types';
import { CheckCircle2, HelpCircle, Target, Clock, FileText, AlertCircle } from 'lucide-react';

interface Props {
  stage: StageData;
}

export const StageDetail: React.FC<Props> = ({ stage }) => {
  const Icon = stage.icon;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header Section */}
      <div className={`${stage.bgLightClass} border ${stage.borderClass} rounded-2xl p-8 mb-8 shadow-sm`}>
        <div className="flex items-center gap-4 mb-4">
          <div className={`p-3 rounded-xl ${stage.colorClass} text-white shadow-md`}>
            <Icon size={32} />
          </div>
          <div>
            <h2 className={`text-3xl font-bold ${stage.textClass}`}>{stage.title}</h2>
            <p className="text-slate-600 text-lg mt-1">{stage.shortDesc}</p>
          </div>
        </div>
        <p className="text-slate-800 text-lg leading-relaxed max-w-4xl">
          {stage.definition}
        </p>
      </div>

      {/* Grid Content */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Left Column */}
        <div className="space-y-6">
          <Card title="Primary Goal" icon={<Target className="text-blue-500" size={20} />}>
            <p className="text-slate-700">{stage.primaryGoal}</p>
          </Card>

          <Card title="What You Need to Start (Prerequisites)" icon={<AlertCircle className="text-amber-500" size={20} />}>
            <ul className="space-y-2">
              {stage.prerequisites.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2 text-slate-700">
                  <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-slate-400 shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </Card>

          <Card title="Key Questions to Answer" icon={<HelpCircle className="text-purple-500" size={20} />}>
            <ul className="space-y-3">
              {stage.keyQuestions.map((item, idx) => (
                <li key={idx} className="flex items-start gap-3 text-slate-700 bg-slate-50 p-3 rounded-lg border border-slate-100">
                  <span className="font-bold text-slate-400">Q.</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          <Card title="Typical Duration" icon={<Clock className="text-slate-500" size={20} />}>
            <p className="text-slate-700 font-medium">{stage.duration}</p>
          </Card>

          <Card title="Success Criteria (Exit Gates)" icon={<CheckCircle2 className="text-emerald-500" size={20} />}>
            <ul className="space-y-2">
              {stage.successCriteria.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2 text-slate-700">
                  <CheckCircle2 className="text-emerald-500 shrink-0 mt-0.5" size={16} />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </Card>

          <Card title="Typical Deliverables" icon={<FileText className="text-indigo-500" size={20} />}>
            <ul className="space-y-2">
              {stage.deliverables.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2 text-slate-700">
                  <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-indigo-300 shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>

      {/* Example Section */}
      <div className="mt-6 bg-slate-800 text-white rounded-2xl p-6 shadow-lg">
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-2">Real-World Example</h3>
        <p className="text-lg leading-relaxed">{stage.example}</p>
      </div>
    </div>
  );
};

// Helper Card Component
const Card: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode }> = ({ title, icon, children }) => (
  <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200 h-full">
    <div className="flex items-center gap-2 mb-4 border-b border-slate-100 pb-3">
      {icon}
      <h3 className="font-semibold text-slate-900">{title}</h3>
    </div>
    {children}
  </div>
);
