import React from 'react';

export type StageId = 'experiment' | 'poc' | 'pov' | 'pilot' | 'scale';

export interface StageData {
  id: StageId;
  title: string;
  shortDesc: string;
  colorClass: string;
  bgLightClass: string;
  borderClass: string;
  textClass: string;
  icon: React.ElementType;
  definition: string;
  primaryGoal: string;
  duration: string;
  prerequisites: string[];
  keyQuestions: string[];
  successCriteria: string[];
  deliverables: string[];
  example: string;
}
